Pokémon Icons (Small) from Pokémon Brilliant Diamond and Shining Pearl ripped by DogToon64.

If used, give credit to Nintendo, The Pokémon Company, and ILCA.

Credit to DogToon64 is optional, but would be nice.